#ifndef CALCULATOR_H
#define CALCULATOR_H
#include <iostream>
class Calculator
{
    public:
        double Add (double, double);
	double Sub (double, double);
        double Mul (double, double);
	void PrintResult(double a, double b);
};

#endif//CALCULATOR_H
